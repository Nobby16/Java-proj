public interface JobSseeker {

        void submitForm();
        void searchJobs();
        void checkStatus();
    }

